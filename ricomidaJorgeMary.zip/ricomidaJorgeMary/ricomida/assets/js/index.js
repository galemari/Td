JavaScript
$(document).ready(function(){
	$("input[id=enviarCorreo]").click(function(){
		alert('El correo fue enviado correctamente...');
	});
});
